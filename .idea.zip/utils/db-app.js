// const {pool} = require("utils/db");
// const {TodoRecord} = require("/records/todo.record");
//
//
// (async() => {
//
//     const foundTodo = await TodoRecord.find('9487419b-623e-4b97-b2fd-1781775b405b');
//     foundTodo.title = 'dz';
//     await foundTodo.update();
//     console.log(foundTodo);
//
//     await pool.end();
//
// })();
//
